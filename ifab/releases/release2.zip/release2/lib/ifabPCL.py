import numpy as np
import matplotlib.pyplot as plt
import pdb


class WeldPieceInfo:

    LeftEdge = [];
    RightEdge = [];
    Angle = [];
    Points3D = [];


class DataPoint2D_Feature:
    def __init__(self, Points2D):
        self.points2D = Points2D;
        N = np.size(Points2D,0);
        Ix = np.arange(0,N);
        self.MeanPt = np.mean(Points2D,0);
        EP2DCentered = Points2D - np.tile(self.MeanPt,[N,1]);
        [D, V] = np.linalg.eig(np.dot((EP2DCentered.T),(EP2DCentered)));
        
        if (D[1] > D[0]):  # Order the eigenvalues
            V = np.roll(V,1,1);
        
        self.majorAxis = V[:,0];
        self.minorAxis = V[:,1];
        
        ProjectionMajor = np.dot(Points2D,self.majorAxis);
        ProjectionMinor = np.dot(Points2D,self.minorAxis);
        Lmin = np.min(ProjectionMajor);
        Lmax = np.max(ProjectionMajor);
        Wmin = np.min(ProjectionMinor);
        Wmax = np.max(ProjectionMinor);
        
        self.dataLength = round(abs(Lmax - Lmin));
        self.dataWidth = round(abs(Wmax - Wmin));
        
        self.majorAxisAngle = np.arctan2(V[1,0],V[0,0]); #Angle = atand(V(2,2)/V(1,2));
        self.minorAxisAngle = np.arctan2(V[1,1],V[0,1]);
        
        self.M = np.tan(self.majorAxisAngle); # parameters of line: y = Mx + c
        self.c = self.MeanPt[1] - self.MeanPt[0]*self.M;

        self.pointMin_Major = (((ProjectionMajor == Lmin).nonzero())[0])[0];
        self.pointMax_Major = (((ProjectionMajor == Lmax).nonzero())[0])[0];
        self.pointMin_Minor = (((ProjectionMinor == Wmin).nonzero())[0])[0];
        self.pointMax_Minor = (((ProjectionMinor == Wmax).nonzero())[0])[0];

#### Custom function to remove rows/columns from a 2-d array

def Delete_False_Dim ( Logical_Vector, In_Matrix, Axis = 0 ):

    N = len(Logical_Vector);

    if (np.sum(Logical_Vector) > 0):    
    
        N_R = np.arange(0,N);
        To_Keep = N_R[Logical_Vector];

        if (Axis == 0):
            Out_Matrix = In_Matrix[To_Keep,:];
        
        elif ( Axis == 1 ):
            Out_Matrix = In_Matrix[:,To_Keep];
        
        else:
            print " Function Only Meant for 2-D Matrices "
            return
    else :
        Out_Matrix = In_Matrix ;
        
    return OutMatrix
        
#### Function to Sequence the input 4DPoints (Last dimension corresponds to Sequence Data)


def iFAB_PCL_Sequence( Points4D, pltFlag = 0 ):

    N = Points4D.shape[0]; #N = size(Points4D,1);
    Seq = 0; #Seq = 1;

    SequenceIx = np.arange(0,N);
    SortedSequence = np.zeros(N);
    
    
    # Sequentialize Data from Index Marker

    SeqData = Points4D[:,3];
    SeqData1 = np.roll(SeqData,-1);
    SeqDiff = (SeqData - SeqData1); # Find Difference between adjacent values
    SeqDiff = np.delete(SeqDiff,[SeqDiff.size - 1]);

    # Identify huge jumps as folds

    FoldPos = (SeqDiff > 1024);
    Folds = sum(FoldPos);
    CarryOverFlag = 0;
    IxBuffer = np.array([0]);
    CarryOverBuffer = np.array([0,0,0,0]);
    if (Folds > 0):

        print "\t\t Total Folds Identified : ", Folds, "\n";
        FoldIx = SequenceIx[FoldPos];
        F_ix = np.arange(0,FoldIx.size)
        Fd = np.roll(FoldIx,-1);
        
        Overlapped = (abs(FoldIx - Fd) < 100);
        Overlapped[-1] = 0;

        for i in xrange(0,Folds):
            
            if np.logical_not((Overlapped[i])):

                BufferData = Points4D[Seq:(FoldIx[i] + 1),3];   # Get first set
                I = np.argsort(BufferData);                     # Sort picked fold
                SortedSequence[Seq:FoldIx[i] + 1] = I + Seq;    # Save sorted fold
                Seq = FoldIx[i] + 1;                            # Update fold index
                
                if CarryOverFlag: # if previous folds were redundant act accordingly
                    In_Ix = np.arange(0,IxBuffer.size - 1);
                    Points4D = np.insert(Points4D,In_Ix + Seq,CarryOverBuffer[1:,:],0); # re-insert removd values into next fold
                    CarryOverBuffer = np.array([[0],[0],[0],[0]]); # empty accumulated buffer
                    FoldIx = FoldIx + IxBuffer.size - 1; # update index values
                    IxBuffer = np.array([0]); #reset redundant fold count
                
                if (i==(Folds-1)):                                  # If last fold index, sort the rest

                    I = np.argsort(Points4D[Seq:,3]);
                    SortedSequence[Seq:] = Seq + I;
                
                CarryOverFlag = 0;
                CarryOverBuffer = np.array([0,0,0,0]);
            
            else:
                
                CarryOverFlag = 1; # Mark for adding values into next fold
                IxBuffer = np.hstack((IxBuffer,FoldIx[i]+1));   # Monitor fold overlaps 
  
                CarryOverBuffer = np.vstack((CarryOverBuffer,Points4D[FoldIx[i]+1,:]))  # Accumulate Values at overlapping folds               
                
                B = np.zeros([np.size(Points4D,0),1]); # remove the values at overlapping folds
                B = B+1;
                B[FoldIx[i]+1] = 0;
                B = B.flatten();
                Points4D = np.compress(B,Points4D,0);
                
                FoldIx = FoldIx - 1; # update fold index after popping a value

    else:

        print "\t\t No Folds Identified"
        I = np.argsort(Points4D[:,3]);
        SortedSequence = I;
       

    OutOfSequence = sum(SortedSequence != SequenceIx);
    print "\t\t Points out of Sequence: ", OutOfSequence, "\n";   
    Points3D = Points4D[np.int64(SortedSequence),0:3];
    pdb.set_trace();
    
    

    return Points3D

#### Function to remove noise/ambiguities from the sensor while identifying the End Points


def End_Point_CleanUp(Points3D, EP, EP_Idx):

    MeanZ = np.mean(Points3D[:,2]);
    MeanY = (max(Points3D[:,1]) - min(Points3D[:,1]))/2;
    N = np.size(EP,0);

    N_R = range(0,N);

    EP_Z = EP[:,2];
    Ix = (EP_Z > MeanZ);
    
   
    
    EP = Delete_False_Dim(np.logical_not (Ix), EP);
    EP_Idx = Delete_False_Dim(np.logical_not(Ix),EP_Idx);

    if (sum(Ix) > 0 ):
        print "\t\tCondition 1 violated "

    EP_Y = EP[:,1];
    E2 = np.roll(EP_Y,-1);
    
    RangeVal = abs(EP_Y - E2);

    Ix_R = RangeVal < MeanY ;
    Ix_R[-1] = 0;
    Ix_R = np.roll(Ix_R,1);

    EP = Delete_False_Dim(np.logical_not(Ix_R), EP);
    EP_Idx = Delete_False_Dim(np.logical_not(Ix_R), EP_Idx);

    if (sum(Ix_R) > 0 ):
        print "\t\tCondition 2 violated "

    return (EP, EP_Idx)


#### Function to identify the End Points (EP) for each 'Pass'


def iFAB_PCL_PassEndPoints( Points3D ):

    X_Val = Points3D[:,1];
    N = len(X_Val);
    EP_Idx = np.arange(0,N);
    X_Val2 = np.roll(X_Val,-1);

    Diff1 = X_Val2 - X_Val;
    Diff1 = np.delete(Diff1, [N-1]);

    ValSlope = np.sign(Diff1);
    ####
    ValSlope[ValSlope == 0] = 1;

    Diff2 = (np.roll(ValSlope,-1) - ValSlope);
    Diff2 = np.delete(Diff2,[len(Diff2) - 1]);

    DiffAbs = abs(Diff2);
    V = DiffAbs == 2;
    EP_Idx = EP_Idx[V];
    EP = Points3D[V,:];

    EP = np.vstack((EP, Points3D[-1,:]));
    EP_Idx = np.hstack((EP_Idx,N));

    (EP, EP_Idx) = End_Point_CleanUp(Points3D, EP, EP_Idx);

    return (EP, EP_Idx)

#### Function to extract the Edges of the Work Piece by identifying them as jumps along the Z - Axis


def iFAB_PCL_ExtractEdges ( Points3D, EP_Idx ):

    Edge1 = EP_Idx;
    Edge2 = np.roll(EP_Idx,-1);
    MeanZ = np.mean(Points3D[:,2]);

    Edge1 = np.delete(Edge1, [(len(Edge1) -1)]);
    Edge2 = np.delete(Edge2, [(len(Edge2) -1)]);

    N = len(Edge1);

    EdgeArray = np.array([0]);
    Flag = 0;

    for i in range(0,N):
    
        BufferPts = Points3D[Edge1[i]:Edge2[i],2];

        if (len(BufferPts) > 5):

            Idx_Val = np.arange(Edge1[i],Edge2[i]) ;
        
            BufferPts2 = np.roll(BufferPts,-1);
        
            Diff1 = BufferPts2 - BufferPts;
            Diff1 = np.delete(Diff1,[(len(Diff1) - 1)]);
            Diff1 = abs(Diff1);
        
            MeanDiff = np.mean(Diff1);
            StdDiff = np.std(Diff1);
            ZScore = (Diff1 - MeanDiff)/StdDiff;
            OutlierCheck = sum(ZScore > 3);
            
            
             
            Idx = ZScore>3;
            C = Idx_Val[Idx];
            C_Z = Points3D[C,2];
        
            Ix = C_Z < MeanZ;
            #C = C';
            C[Ix] = C[Ix] + 1;
        
            if (OutlierCheck == 2):
                if Flag:
                    C = np.roll(C,1);
                EdgeArray = np.hstack((EdgeArray, C));
#                if (Flag and (EdgeArray.size == 3)):
#                    EdgeArray = np.array([0]);
#                    print "\t\t First Pass missed -- Flipping points to maintain pattern \n";
            else:
                print "\t\tOutlier Detected at pass ", i, "\n"
                Flag = not Flag;

    EdgeArray = np.delete(EdgeArray,[0]);
    n1 = len(EdgeArray);
    EdgePt3D = Points3D[EdgeArray,:];
    return EdgeArray



#### Function to calculate orientations from the extracted edges 

def iFAB_PCL_GetOrientation ( EdgePoints3D ):

    N = np.size(EdgePoints3D,0);
    EdgeL1 = np.arange(0,N,4);
    EdgeL2 = EdgeL1 + 3;
    T_Ix = EdgeL2 > (N-1);
    EdgeL2 = Delete_False_Dim(np.logical_not(T_Ix),EdgeL2);
    
    EdgeLIx = np.hstack((EdgeL1, EdgeL2));
    Ix = np.arange(0,N);
    Ix[EdgeLIx] = 0;
    T_Ix = np.logical_not(Ix == 0);
    Ix = Delete_False_Dim(T_Ix,Ix); #Ix(Ix==0) = [];
    EdgeRIx = Ix;

    EdgeL = EdgePoints3D[EdgeLIx,:];
    EdgeR = EdgePoints3D[EdgeRIx,:];

    MeanL = np.mean(EdgeL,0);
    MeanR = np.mean(EdgeR,0);
      
    
    EdgeL_C = EdgeL - np.tile(MeanL,[np.size(EdgeL,0),1]);
    EdgeR_C = EdgeR - np.tile(MeanR,[np.size(EdgeR,0),1]);

    W = np.vstack((EdgeL_C,EdgeR_C));
    
    Angle_L = iFAB_PCL_Local_FindEdgeOrienataion(EdgeL);
    print "\t\tLeft Edge Orientation: ",Angle_L * (180/np.pi), "\n";

    Angle_R = iFAB_PCL_Local_FindEdgeOrienataion(EdgeR);
    print "\t\tRight Edge Orientation: ",Angle_R * (180/np.pi), "\n";

    Angle_Cumulative = iFAB_PCL_Local_FindEdgeOrienataion(W);
    print "\t\tCumulative Edge Orientation: ", Angle_Cumulative * (180/np.pi), "\n";

    WP = WeldPieceInfo();

    WP.LeftEdge = MeanL;
    WP.RightEdge = MeanR;
    WP.Angle = Angle_Cumulative;

    return WP

#### Function assosciated with the math of edge direction calculation

def iFAB_PCL_Local_FindEdgeOrienataion (EdgePoints3D):

    EP2D = EdgePoints3D[:,0:2];
    N = np.size(EP2D,0);
    MeanPt = np.mean(EP2D,0);
    EP2DCentered = EP2D - np.tile(MeanPt,[N,1]);

    [D, V] = np.linalg.eig(np.dot((EP2DCentered.T),(EP2DCentered)));
    Angle = np.arctan2(V[1,0],V[0,0]); #Angle = atand(V(2,2)/V(1,2));

    return Angle
    
    
    
def iFAB_WorkPiece_Data (Points4D):
    
    P3D = iFAB_PCL_Sequence(Points4D);
    [EP, EP_Idx] = iFAB_PCL_PassEndPoints(P3D);
    EdgeArray = iFAB_PCL_ExtractEdges(P3D, EP_Idx);
    EdgePoint3D = P3D[EdgeArray,:];
    W = iFAB_PCL_GetOrientation(EdgePoint3D);
    W.Points3D = P3D
    return W
    
    
    
def iFAB_Weld_Points (P1, P2):
    
    w2 = iFAB_WorkPiece_Data(P1);
    w1 = iFAB_WorkPiece_Data(P2);

    ML1 = w1.LeftEdge;
    ML2 = w2.RightEdge;
    MR1 = w1.RightEdge;
    MR2 = w2.LeftEdge;
    
    

    Z = max([ML1[2], ML2[2], MR1[2], MR2[2]]);

    P1 = w1.Points3D;
    P2 = w2.Points3D;

    L1_m = np.tan(w1.Angle);
    L2_m = np.tan(w2.Angle);
    R1_m = L1_m;
    R2_m = L2_m;

    L1_c = w1.LeftEdge[1] - w1.LeftEdge[0]*L1_m;
    R1_c = w1.RightEdge[1] - w1.RightEdge[0]*R1_m;
    L2_c = w2.LeftEdge[1] - w2.LeftEdge[0]*L2_m;
    R2_c = w2.RightEdge[1] - w2.RightEdge[0]*R2_m;

    X_L = Calculate_Intersection(L1_m,L2_m,L1_c,L2_c);
    X_R = Calculate_Intersection(R1_m,R2_m,R1_c,R2_c);
    
    x_L = Calculate_Intersection(L1_m,R2_m,L1_c,R2_c);
    x_R = Calculate_Intersection(R1_m,L2_m,R1_c,L2_c);
    
    
    
    D1  = X_L - X_R;
    D2  = x_L - x_R;
    
    d1 = D1.T * D1;
    d2 = D2.T * D2;
    
    if (d1 < d2):
    	
    	X_R = (np.array(np.vstack((X_R,Z)))).flatten();
    	X_L = (np.array(np.vstack((X_L,Z)))).flatten();
    	return [X_L,X_R]
    else:
    	x_R = (np.array(np.vstack((x_R,Z)))).flatten();
    	x_L = (np.array(np.vstack((x_L,Z)))).flatten();
    	return [x_L,x_R]
  

def Calculate_Intersection (m1,m2,c1,c2):

    A = np.array([[-m1, 1],[-m2, 1]]);
    B = ([[c1],[c2]]);
    
    A = np.matrix(A);
    B = np.matrix(B);    
    
    X_Int = np.linalg.solve(A,B);
    return X_Int

def Calculate_ZigZag_Pattern (model_A, passes=5, widthFactor=1.5, lengthFactor=.5, Z=-100):

    a = DataPoint2D_Feature(model_A);
    
    Intersection = a.MeanPt + a.majorAxis*(a.dataLength/2);    
   
    a_Away = a.MeanPt - Intersection;
    a_Away = a_Away/(np.sqrt((np.dot(a_Away,a_Away))));
    
    a_Start = a_Away*a.dataLength/3 + Intersection;
    


    a_End = a_Away*a.dataLength*lengthFactor + a_Start;
    
    a_offset = a.dataWidth*a.minorAxis*widthFactor;
    
    Flip = np.array([[1, 1],[-1, -1]]);
    FlipTot = np.tile(Flip,[2*passes,1]);

    a_offset = np.tile(a_offset,[2*passes,1]);
    n = 3 + (passes - 1)*2;
    N = (2*n) - 1;
    
   
    Idx = np.arange(1,N+1);
    Idx = np.mod(Idx,2)
    Idx = np.logical_not(Idx);
    Extrema = Idx.nonzero();
    
    a_x = (np.linspace(a_Start[0],a_End[0],N))[Extrema];
    a_y = (np.linspace(a_Start[1],a_End[1],N))[Extrema];
    a_extrema = (np.vstack((a_x,a_y))).T;
    
    n1 = a_extrema.shape[0];
    #pdb.set_trace();
    FlipTot = FlipTot[0:n1,:];
    a_extrema = a_extrema + a_offset*FlipTot;
    
    Z = np.tile(Z,[n1,1]);
    a_extrema = np.hstack((a_extrema,Z));
    
   
    
    return a_extrema



    
    
    
    
            
        
    
