import struct, numpy, json, sys, time, Queue, os
import matplotlib.pyplot as plt

import robot, projector, ifabPCL
from quickhull import qhull
import Gnuplot, pdb

class stlModel:
    #inital load part of class based on code from StackOverflow user 'DaClown'
    def __init__(self, key=None, filename=None):      
        self.normals = []; self.points = []; 
        self.triangles = [];self.bytecount = []
        self.fb = [] 

        if key <> None: self.load(('models/' + key + '.stl'))
        elif filename <> None: self.load(filename)

    def unpack (self, f, sig, l):
        s = f.read(l)
        self.fb.append(s)
        return struct.unpack(sig, s)

    def read_triangle(self, f):
        n = self.unpack(f,"<3f", 12)
        p1 = self.unpack(f,"<3f", 12)
        p2 = self.unpack(f,"<3f", 12)
        p3 = self.unpack(f,"<3f", 12)
        b = self.unpack(f,"<h", 2)
        self.normals.append(n)
        l = len(self.points)
        self.points.append(p1)
        self.points.append(p2)
        self.points.append(p3)
        self.triangles.append((l, l+1, l+2))
        self.bytecount.append(b[0])

    def read_length(self, f):
        length = struct.unpack("@i", f.read(4))
        return length[0]

    def read_header(self, f):
        f.seek(f.tell()+80)

    def write_as_ascii(self, outfilename):
        f = open(outfilename, "w")
        f.write ("solid "+outfilename+"\n")
        for n  in range(len(self.triangles)):
            f.write ("facet normal {} {} {}\n".format(self.normals[n][0],self.normals[n][1],self.normals[n][2]))
            f.write ("outer loop\n")
            f.write ("vertex {} {} {}\n".format(self.points[self.triangles[n][0]][0],self.points[self.triangles[n][0]][1],self.points[self.triangles[n][0]][2]))
            f.write ("vertex {} {} {}\n".format(self.points[self.triangles[n][1]][0],self.points[self.triangles[n][1]][1],self.points[self.triangles[n][1]][2]))
            f.write ("vertex {} {} {}\n".format(self.points[self.triangles[n][2]][0],self.points[self.triangles[n][2]][1],self.points[self.triangles[n][2]][2]))
            f.write ("endloop\n")
            f.write ("endfacet\n")
        f.write ("endsolid "+outfilename+"\n")
        f.close()

    def load(self, infilename):
        self.normals = []; self.points = []
        self.triangles = []; self.bytecount = []
        self.fb = []

        try:
            f = open (infilename, "rb")
            self.read_header(f)
            l = self.read_length(f)
            try:
                while True:
                    self.read_triangle(f)
            except Exception, e: pass
            if len(self.triangles) <> l:
                print len(self.normals), len(self.points), len(self.triangles), l
        except Exception, e: pass

    def transform(self, tmat):
        if (numpy.shape(tmat) <> (4,4)): return False
        for i in xrange(len(self.points)):
            self.points[i] = (numpy.dot(tmat, numpy.append(self.points[i],1)))[0:3]
    
    def project2D(self):
        return numpy.array(self.points)[:,0:2]

    #pts is (n,2), function returns distance between consecutive points
    def edgeLength(self, pts):
        p = numpy.diff(pts, axis=0)
        lenEdges = numpy.sqrt(numpy.sum(p*p, axis = 1))
        return lenEdges


    def project(self, R, sDist = 50, sHeight = 800):
        p = projector.Projector()
        points = self.project2D()
        hull = qhull(points); dmin = 1e9; ind = -1
        for i in numpy.argsort(self.edgeLength(hull))[-2:]:
            dist = numpy.abs(numpy.mean([hull[i], hull[i+1]], axis=0)[1])
            print dist
            if dist < dmin: dmin = dist; ind = i
        projPt2D = hull[ind:ind+2,:]
        projPt3D = projector.projectPlane(projPt2D)
       
        center = numpy.mean(projPt3D, axis=0)

        n = projector.unitv(numpy.cross([0,0,1], numpy.diff(projPt3D, axis=0)))
        rPosition = center + n*sDist + [0,0,sHeight]
        #rnPosition = center + -1*n*sDist + [0,0,sHeight]
        
        #if numpy.abs(numpy.dot(rpPosition, rpPosition)) < numpy.abs(numpy.dot(rnPosition, rnPosition)): rPosition = rpPosition
        #else: rPosition = rnPosition

        vt = projector.virtual(center, rPosition)
        
        #print 'vt',  vt
        print 'pp3d', projPt3D

        seg = projector.Segments(projPt3D)

        

        gltm = projector.segProjections(vt,seg)
        print 'gltmcheck', projector.GLtmCheck(gltm)
      
      
        R.setToolFile('C:/Users/mikedh/Dropbox/cmu/svnmain/trunk/data/tool.object.projector')
        R.setCartesian(vt)

        p.send(gltm)
        #p.send(projector.ccbGLTM())
        p.doorOpen(1)
        #plt.hold(True)
        #plt.plot(hull[:,0], hull[:,1], '.', hull[ind:ind+2,0],  hull[ind:ind+2,1], rPosition[0], rPosition[1], 'o')
        #plt.show()
        raw_input('projecting member')
        p.doorOpen(0)

#takes a list of models and inspects them, returning 'some stuff'
class Inspector:
    def __init__(self):
        self.items = dict()
        self.clouds = dict()
        self.ingress = dict()
        self.trunk =  os.getcwd()[0:(6+os.getcwd().rfind('trunk'))]


    def add(self, name, stl, ingress):
        if stl.__class__.__name__ == 'stlModel':
            self.items[str(name)] = stl
            self.ingress[str(name)] = ingress
        else: print 'item not an stlModel'

    def inspect(self, R=None, L=None, plotting=True):
        
        for name, model in self.items.iteritems():
            
            plan = self.inspectionPlan(name, model)
            print 'now inspecting', name, 'plan shape', plan.shape, 'model shape', numpy.shape(model.points)
           
            #plt.plot(plan[:,0], plan[:,1], 'o', numpy.array(model.points)[:,0], numpy.array(model.points)[:,1], '.')
            #plt.show()

            
            
            if R.__class__.__name__ == 'Robot':
                if (plan <> None) & (plan <> []):
                    if (R.setToolFile(self.trunk + 'data/tool.object.displacement') == False): return False
                    R.setJoints(self.ingress[name])
                    if R.setBuffer(plan, gotoFirst=True):
                        if L == None: L = robot.Logger()
                        time.sleep(1)
                        L.start()
                        R.executeBuffer()
                        time.sleep(.5)
                        self.clouds[name] = L.stop(sequence=True)
                        
                        try: print 'recorded', len(self.clouds[name]), 'points for', name
                        except: print 'recorded no data'
        if L <> None: L.close()
            
        
    def alignWeld(self, weld):
        #loop through clouds, and return the location of the weld.
        k = self.clouds.keys()
        wq  =  [0.43837115, 0. ,  0.89879405,  0.]
        if (len(k) == 2):
            points = ifabPCL.iFAB_Weld_Points(self.clouds[k[0]], self.clouds[k[1]])
            weldpoints = [];
            for i in points:
                weldpoints.append([i,wq])
            return numpy.array(weldpoints)

    def dump(self):
        for name, cloud in self.clouds.iteritems():
            numpy.savetxt((self.trunk + 'data/scans/cloud-' + str(name) + time.strftime('%d-%H%M') + '.txt'), cloud)

    def clear(self):
        self.items = dict()
        self.clouds = dict()


    #assumes the model is a tubular member, so that a line fit 
    #finds the approximate axis of the member.
    #output is a list of xyz points to inspect (n,3) 
    def inspectionPlan(self, name, model):
        #this is a placeholder function which loads 

        pts = model.project2D()
        tq = [0,0,1,0]; plan = []
        xyz = ifabPCL.Calculate_ZigZag_Pattern(pts)
        for i in xyz: plan.append([i, tq])
        return numpy.array(plan)


    def close(self):
        try: self.L.close()
        except: pass

    def __del__(self):
        self.close()

def measurePlane(R, L, height):
    tq = [0,0,1,0]
    ipt = [[1460,-870,-100], [1460,700,-100], [1820,0,-100]]
    plane = []

    if (R.setToolFile('C:/Users/mikedh/Dropbox/cmu/svnmain/trunk/data/tool.object.displacement') == False): return False
    for i in ipt:
        print i
        R.setCartesian([i,tq])
        time.sleep(2)
        L.start()
        time.sleep(1)
        plane.append(numpy.mean(L.stop(), axis = 0))


    return numpy.array(plane)
