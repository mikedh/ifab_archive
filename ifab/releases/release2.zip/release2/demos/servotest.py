
import ue9
import sys
from time import sleep

# Open the U3
d = ue9.UE9()

def sensorDoor(daq, doorstate):
    doorlist = [60250, 61950] #[open, closed]
    doorindex = int(int(doorstate)>0)
    doorval = doorlist[doorindex]

    print doorval

    daq.timerCounter(UpdateConfig = True, NumTimersEnabled = 2,  TimerClockBase = 4, TimerClockDivisor = 15, Timer0Mode = 0, Timer1Mode = 0, Timer0Value = 60600, Timer1Value =doorval)
    sleep(3)
    


if __name__ == '__main__':
    for i in [0,1]:
        sensorDoor(d, i)
    d.timerCounter(UpdateConfig = True, NumTimersEnabled = 0)

d.close

