import ue9

d = ue9.UE9()
d.streamStop()
d.close()

