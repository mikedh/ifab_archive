import robot

r = robot.Robot(zeroJoints=True)

r.setCartesian([[1250,0,600], [0,0,1,0]])

for i in range(2):
    r.setCircular([[1350,100,600], [0,0,1,0]], [[1450,0,600], [0,0,1,0]])
    r.setCircular([[1350,-100,600], [0,0,1,0]], [[1250,0,600], [0,0,1,0]])
