'''
Michael Dawson-Haggerty
CMU Robotics Institute
For Dr. David Bourne/iFAB


ifab-main.py: main level iFAB welding script
Used to load a generic iFAB welding format zip file
usage: python ifab-main.py ifab-file.zip (-w: enables welding vs simulated welding)

Loops through a JSON structure and reads/manipulates 3D models based on the information contained.

Physical placement of a member is guided with a laser projection system, scanned resulting in a point cloud, and then that very accurate data is used to align the weld, so that parts which are misaligned on an absolute scale, but correct on a relative scale can succeed. We can also use this data to calculate if the relative positions are within tolerance before welding. 
'''


import json, os, shutil, sys, time
from zipfile import ZipFile
import robot, ifabModel


if __name__ == '__main__':

    #find local trunk location, assuming checkout from our SVN
    trunk = os.getcwd()[0:(6+os.getcwd().rfind('trunk'))]
    filename = trunk + 'workpiece-files/exchange-testcase.zip'
    
    #block to load iFAB file specified 
    welding = '-w' in sys.argv
    for arg in sys.argv[1:]:
        if os.path.exists(arg): filename = arg; break
        elif os.path.exists(trunk+'workpice-files/'+arg): filename = trunk+'workpice-files/'+arg; break


        

    extractDir = '.tmp'
    with ZipFile(filename, 'r') as archive:
        archive.extractall(extractDir)
    os.chdir(extractDir)
    try: j = json.load(open('metadata.json', 'r'))
    except: 'failed to load metadata.json, exiting'; sys.exit()

    #with input file loaded, loop through it
    try: 
        R = robot.Robot(verbose = True, zeroJoints=True)
        I = ifabModel.Inspector()

        #each task includes a number of elements which must be positioned
        #once all members in a task are positioned, we execute the welds contained in the same task
        for task in j['tasks']:
            for position in task['positioning']:

                #load the 3D model of the current member, then translate it to its pre-planned position in the iFAB cell
                model = ifabModel.stlModel(position['memberName'])
                model.transform(position['transformationMatrix'])

                #execute pre-planned ingress joint path, to avoid hitting things on the way to locate parts
                R.setJoints(position['ingress'])

                #once the robot is in position, project the outline of the part for a worker to align the member
                model.project(R)

                #add the current member to the inspection subsystem, so we can locate the part very accurately 
                I.add(position['memberName'], model, position['ingress'])

            #after all parts in the task are in place, we can then inspect the scene to find exactly where the parts are 
            I.inspect(R)

            #a debugging command, dumps the point clouds of the inspection to trunk/data/scans, with a timestamp.
            I.dump()

            for weld in task['welds']:
                #approach the welds contained in the task
                R.setJoints(weld['ingressMoves'])
                
                #use the point cloud data to align the weld, given in model coordinates, into actual physical space
                weldPoints = I.alignWeld(weld['weldLine']['waypoints'])

                #execute weld, either as a linear move or an actual weld
                R.setToolFile(trunk + 'data/tool.object.welder')
                R.setBuffer(weldPoints)
                if welding: R.weldBuffer()
                else: 
                    R.setCartesian(weldPoints[-1])
                    R.setSpeed((25,25))
                    R.executeBuffer()
                time.sleep(5)
                R.setSpeed()
                R.setJoints()
                    
    finally:
        del R
        os.chdir('..')
        shutil.rmtree(extractDir)
        
